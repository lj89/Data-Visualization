package kernel;
import processing.core.*;
abstract class Abstract3DObject
{
  protected PVector position;
  protected PApplet p;
  
  public Abstract3DObject(PApplet _p)
  {
    p=_p;
    position = new PVector(0, 0, 0);
  }
  
  public void setPosition(PVector _pos)
  {
    position = _pos;
  }
  
  protected void transform(){};
  protected abstract void createObject();
  
  public void render()
  {
    p.pushMatrix();
      transform();
      createObject();
    p.popMatrix();
  }
}
