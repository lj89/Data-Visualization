package kernel;
import processing.core.*;
class DataObject extends Abstract3DObject
{ 
  public DataObject(PApplet _p)
  {
    super(_p);
  }

  public int groupColor;
  public DataObject(float x, float y, float z, int g,PApplet _p) //, color groupColor
  {
    super(_p);
    setPosition(new PVector(-x, -y, z));
    groupColor = g;
  }
  
  public void transform()
  {
    p.translate(position.x, position.y, position.z);
  }
  
  protected void createObject()
  {
    //fill(255, 0, 0);
    p.fill(groupColor*40,(6-groupColor+1)*40,150);
    //fill(groupColor);
    p.noStroke();
    p.sphereDetail(5);
    p.sphere(5);
    p.fill(255);
    p.stroke(0);
  }
}
