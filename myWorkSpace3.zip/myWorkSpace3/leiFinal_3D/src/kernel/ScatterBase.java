package kernel;
import processing.core.*;
import java.util.ArrayList;

class ScatterBase extends Abstract3DObject
{
  private int sizeWidth;
  private int sizeHeight;
  private int sizeDepth;
  private ArrayList<DataObject> dataObjects;
  private PImage texture;
  //private int groupColor;
  
  public ScatterBase(PApplet _p)
  {
    super(_p);
    sizeWidth = 300;
    sizeDepth = 500;
    sizeHeight = 700;
    dataObjects = new ArrayList<DataObject>();
    texture =p.loadImage("all1943updated.png");
    //groupColor = 5;
    //groupColor = 1;
  }
  
  public ScatterBase( int _width, int _height, int _depth,PApplet _p) //, int _groupColor
  {
    //super(_p);
    this(_p);
    sizeWidth = _width;
    sizeDepth = _depth;
    sizeHeight = _height;
    //groupColor= _groupColor;
  }
  
  public void addPoint(float w, float d, float h, int  g)//, PApplet _p
  {
    DataObject newPoint = new DataObject(w, d, h, g, p); //
    dataObjects.add(newPoint);
  }
  
  protected void createObject()
  {
    PShape box =p.createShape(PApplet.BOX, -sizeWidth,10,sizeDepth);
    box.setTexture(texture);
    p.shape(box);
    //box(sizeWidth, 10, sizeDepth);
    p.pushMatrix();
      p.translate(sizeWidth/2, -10, -sizeDepth/2);
      p.line(0, 0, 0, 0, -sizeHeight, 0); 
    p.popMatrix();
    p.pushMatrix();
      p.translate(sizeWidth/2, -10, -sizeDepth/2);
      for(DataObject o : dataObjects)
      {
        o.render();
      }
    p.popMatrix();
  }
  
 
}
