package kernel;
import processing.core.*;
class CustomCamera
{
  private PVector position;
  private PVector direction;
  private float angleX;
  private float angleY;
  
  private static final float MIN_ANGLE_X = -PApplet.PI/4;
  private static final float MAX_ANGLE_X = 0;
  private static final float MIN_ANGLE_Y = -PApplet.PI/2;
  private static final float MAX_ANGLE_Y = PApplet.PI/2;
  private static final float ANGLE_Y_SPEED = 0.03f;
  private static final float ANGLE_X_SPEED = 0.03f;
  
  private float lastDragX;
  private float lastDragY;
  private PApplet p;
  
  public CustomCamera(PApplet _p)
  {
    p=_p;
    position = new PVector(0, -100, 500);
    direction = new PVector(0, -100, 0);
    angleX = 0;
    angleY = 0;
  }
  public void use()
  {
    p.beginCamera();
      p.camera( position.x, position.y, position.z, 
              direction.x, direction.y, direction.z, 
              0, 1, 0);
      p.rotateY(angleY);
      p.rotateX(angleX);
    p.endCamera();
  }
  
  public void dragged()
  {
    rotateCamera();
  }
  
  private void rotateCamera()
  {
    if(p.mouseX > lastDragX)
    {
      lastDragX = p.mouseX;
      angleY += ANGLE_Y_SPEED;
      if(angleY > MAX_ANGLE_Y)
      {
        angleY = MAX_ANGLE_Y;
      }
    }
    else if (p.mouseX < lastDragX)
    {
      lastDragX = p.mouseX;
      angleY -= ANGLE_Y_SPEED;
      if(angleY < MIN_ANGLE_Y)
      {
        angleY = MIN_ANGLE_Y;
      }
    }
    if(p.mouseY > lastDragY)
    {
      lastDragY = p.mouseY;
      angleX += ANGLE_X_SPEED;
      if(angleX > MAX_ANGLE_X)
      {
        angleX = MAX_ANGLE_X;
      }
    }
    else if (p.mouseY < lastDragY)
    {
      lastDragY = p.mouseY;
      angleX -= ANGLE_X_SPEED;
      if(angleX < MIN_ANGLE_X)
      {
        angleX = MIN_ANGLE_X;
      }
    }
  }
}
